package web.wittyoutfit.model;

public enum Alive {
     ACTIVATED,NOT_ACTIVATED;
}
