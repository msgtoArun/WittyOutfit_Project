package web.wittyoutfit.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Type;

@SuppressWarnings("deprecation")
@Entity
@Table(name = "tb_wot_usersdetails", catalog = "db_wittyoutfit")
@org.hibernate.annotations.Entity(dynamicUpdate = true)
public class Users {

	@Id
	@Column(name = "prof_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.TABLE,generator = "TABLE")
	@TableGenerator(pkColumnName = "field",valueColumnName = "sequence",table = "sequence_table",name = "TABLE",initialValue = 0,pkColumnValue = "prof_id")
	private int userId;
	@Column(name = "mail_id",nullable = false)
	private String mail;
	@Column(name = "education", nullable = true)
	private String education;
	@Column(name = "occupation", nullable = true)
	private String occupation;
	@Column(name = "location", nullable = true)
	private String location;
	@Column(name = "Skills", nullable = true)
	private String skills;
	@Column(name = "full_name", nullable = true)
	private String fullName;
	@Column(name = "phone", nullable = true)
	private String phoneNo;
	@OneToOne(fetch = FetchType.LAZY)
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}


}