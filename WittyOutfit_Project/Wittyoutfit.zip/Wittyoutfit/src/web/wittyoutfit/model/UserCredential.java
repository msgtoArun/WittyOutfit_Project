package web.wittyoutfit.model;



import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import org.hibernate.annotations.Cascade;

@SuppressWarnings("deprecation")
@Entity
@Table(name = "tb_wot_credential", catalog = "db_wittyoutfit")
@org.hibernate.annotations.Entity(dynamicUpdate = true)
public class UserCredential {
	@Id
	@Column(name = "mail_id", nullable = false)
	private String emailId;
	@Column(name = "password", nullable = false)
	private String password;
	@Column(name = "auth_key")
	private String authKey;
	@Column(name = "Alive")
	private Alive Alive;
	@OneToOne(cascade = CascadeType.ALL)
	private Users users;

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAuthKey() {
		return authKey;
	}

	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	public Alive getAlive() {
		return Alive;
	}

	public void setAlive(Alive alive) {
		Alive = alive;
	}
	
}