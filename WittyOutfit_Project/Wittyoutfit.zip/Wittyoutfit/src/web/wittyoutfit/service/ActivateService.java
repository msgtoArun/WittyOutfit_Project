package web.wittyoutfit.service;

import org.hibernate.Session;

import web.wittyoutfit.util.HBUtil;
import web.wittyoutfit.model.Alive;
import web.wittyoutfit.model.UserCredential;



public class ActivateService {

	public static void get(String email, String identity) {
		UserCredential ue = new UserCredential();
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		UserCredential upd = session.get(UserCredential.class,email);
		upd.setAlive(Alive.ACTIVATED);
		session.update(upd);
		session.getTransaction().commit();
		session.close();
	}

}
