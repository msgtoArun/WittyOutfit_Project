package web.wittyoutfit.service;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import web.wittyoutfit.util.HBUtil;
import web.wittyoutfit.model.Alive;
import web.wittyoutfit.model.UserCredential;
import web.wittyoutfit.model.Users;



public class UserService {

	public static void insert(String username, String password, String email, String phone, String authKey) {
		UserCredential credential=new UserCredential();
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		Users users = new Users();
		users.setPhoneNo(phone);
		users.setMail(email);
		users.setFullName(username);
		credential.setAuthKey(authKey);
	    credential.setAlive(Alive.NOT_ACTIVATED);
		credential.setEmailId(email);
		credential.setPassword(password);
		credential.setUsers(users);
		session.save(credential);
		session.getTransaction().commit();
		session.close();
	}

	public static boolean check(String username, String password) {
		Session session = HBUtil.get().openSession();
		Criteria criteria = session.createCriteria(UserCredential.class);
		criteria.add(Restrictions.eq("emailId", username));
		UserCredential user= (UserCredential) criteria.uniqueResult();
		if(user==null){
			return false;
		}
		else if(password.equals(user.getPassword())){
		    return true;	
		}
		return false;
	}
}
