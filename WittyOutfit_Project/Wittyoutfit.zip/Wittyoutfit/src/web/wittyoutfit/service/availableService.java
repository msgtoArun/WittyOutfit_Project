package web.wittyoutfit.service;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import web.wittyoutfit.util.HBUtil;
import web.wittyoutfit.model.UserCredential;



public class availableService {

	public static boolean available(String mail) {
		Session session = HBUtil.get().openSession();
		Criteria criteria = session.createCriteria(UserCredential.class);
		criteria.add(Restrictions.eq("emailId", mail));
		UserCredential user= (UserCredential) criteria.uniqueResult();
		 if (user == null) {
	            return true;
	        }
		 else
		 {        return false;
		 
		 }
	}

}
