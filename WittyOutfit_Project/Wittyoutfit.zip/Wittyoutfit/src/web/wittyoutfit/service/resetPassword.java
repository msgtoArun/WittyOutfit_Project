package web.wittyoutfit.service;

import org.hibernate.Session;

import web.wittyoutfit.util.HBUtil;
import web.wittyoutfit.model.UserCredential;



public class resetPassword {

	public static void change(String mail,String authKey) {
		UserCredential ue = new UserCredential();
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		UserCredential upd = session.get(UserCredential.class,mail);
		upd.setAuthKey(authKey);
		session.update(upd);
		session.getTransaction().commit();
		session.close();
		
	}

}
