package web.wittyoutfit.service;

import javax.persistence.Query;

import org.hibernate.Session;

import web.wittyoutfit.model.*;
import web.wittyoutfit.util.HBUtil;

public class updateService {

	public static boolean updateprofile(int identity, String name, String phone, String occupation, String location,
			String education, String skill) {
		if(identity!=0) {
			Users ue = new Users();
			Session session = HBUtil.get().openSession();
			session.beginTransaction();
			Users upd = session.get(Users.class,identity);
			upd.setFullName(name);
			upd.setPhoneNo(phone);
			upd.setOccupation(occupation);
			upd.setLocation(location);
			upd.setSkills(skill);
			upd.setEducation(education);
			session.update(upd);
			session.getTransaction().commit();
			session.close();
			return true;
		}else {
			return false;
		}
	}

	public static void password(String mail,String password) {
		UserCredential ue = new UserCredential();
		Session session = HBUtil.get().openSession();
		session.beginTransaction();
		UserCredential upd = session.get(UserCredential.class,mail);
		upd.setPassword(password);
		session.update(upd);
		session.getTransaction().commit();
		session.close();
		
	}

	
       
}
