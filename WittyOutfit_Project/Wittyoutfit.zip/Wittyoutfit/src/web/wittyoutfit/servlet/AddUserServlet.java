package web.wittyoutfit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import web.wittyoutfit.service.UserService;
import web.wittyoutfit.service.mailservice;
import web.wittyoutfit.util.AuthUtil;

/**
 * Servlet implementation class AddUserServlet
 */
@WebServlet("/add_user")
public class AddUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
			String username = request.getParameter("uname");
			String email=request.getParameter("email");
			String password = request.getParameter("password");
			String phone = request.getParameter("phone");
			String authKey = AuthUtil.generateKey(7);
			System.out.print(username);
			System.out.print(email);
			System.out.print(password);
			System.out.print(phone);
			if (username == null || username.isEmpty() || password == null || password.isEmpty() || email == null || email.isEmpty() || phone == null || phone.isEmpty()) {
				out.println("Fill the required fields!");
			} else {
				UserService.insert(username, password,email,phone,authKey);
				response.setContentType("text/html");
				String froma="internshipwittyoutfit@gmail.com";
				String pass="test@success007";
				String subject="Greetings from Witty Outfit";
				String body="Hi"+" "+ email + ",you have successfully created your account. Now activate your account with link +"+ " " + "<a href='http://localhost:8080/wittyoutfit/activateAccount?mail="+ ""+email+ "&key="+""+authKey+"'>CLICK HERE</a>" ;
				mailservice.send(email,froma,pass,subject,body);
				response.getWriter().append("Served at: ").append(request.getContextPath());
				request.getRequestDispatcher("/pages/examples/Authenticate.jsp").forward(request, response);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
