package web.wittyoutfit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import web.wittyoutfit.model.*;
import web.wittyoutfit.service.updateService;
import web.wittyoutfit.util.*;


@WebServlet("/updateDetails")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateServlet() {
        super();
    }
    String value = null;
	boolean res;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		Cookie cookies[] = request.getCookies();
		if(cookies!=null) {
			value = CKUtil.get((HttpServletRequest) request, "usr_alive");
			System.out.println(cookies[0]);
		}
		System.out.println(value);
		try (PrintWriter out = response.getWriter()) {
			String name = request.getParameter("fullname");
			String phone = request.getParameter("phone");
			String occupation = request.getParameter("occupation");
			String location = request.getParameter("location");
			String education = request.getParameter("education");
			String password = request.getParameter("pass");
			String skill =request.getParameter("skills");
			System.out.println(value);
			if(value==null) {
				response.sendRedirect("pages/examples/404.html");
			}else {
				Session session = HBUtil.get().openSession();
				Criteria criteria = session.createCriteria(Users.class);
				criteria.add(Restrictions.eq("mail", value));
				Users user= (Users) criteria.uniqueResult();
				int identity = user.getUserId();
				System.out.println(identity);
				System.out.println(name);
				System.out.println(phone);
				System.out.println(occupation);
				System.out.println(location);
				System.out.println(education);
				System.out.println(skill);
				res = updateService.updateprofile(identity,name,phone,occupation,location,education,skill);
			    if(res == true) {
			    	response.sendRedirect("pages/examples/profile.jsp");
			    }else {
			    	response.sendRedirect("/wittyoutfit/error.html");
			    }
			}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
