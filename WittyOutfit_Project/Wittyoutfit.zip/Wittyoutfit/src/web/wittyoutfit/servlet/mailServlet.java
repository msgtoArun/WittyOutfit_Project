package web.wittyoutfit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import web.wittyoutfit.service.mailservice;


@WebServlet("/mailservlet")
public class mailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public mailServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try(PrintWriter out = response.getWriter()){
			System.out.println("hai");
			String mail = request.getParameter("email");
			String subject = request.getParameter("subject");
			String message=request.getParameter("body");
			message = mail + " "+ "said"+ " " + message;
			if((mail == null) || (subject == null) || (message == null)){
				out.println("Please Fill all the fields");
			}
			else{
				String froma="internshipwittyoutfit@gmail.com";
				String email=mail;
				String password="test@success007";
				mailservice.vsend(email, froma, password, subject, message);
			}
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hai");
		doGet(request, response);
	}

}
