package web.wittyoutfit.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import web.wittyoutfit.util.HBUtil;
import web.wittyoutfit.model.UserCredential;
import web.wittyoutfit.service.ActivateService;


/**
 * Servlet implementation class ActivateUser
 */
@WebServlet("/activateAccount")
public class ActivateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("mail") ;
		String key = request.getParameter("key");
		System.out.println(email);
		System.out.println(key);
		Session session = HBUtil.get().openSession();
		Criteria criteria = session.createCriteria(UserCredential.class);
		criteria.add(Restrictions.eq("emailId", email));
		UserCredential user= (UserCredential) criteria.uniqueResult();
		String test = user.getAuthKey();
		String identity = user.getAuthKey();
		if(test.equals(key)) {
			ActivateService.get(email,identity);
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.sendRedirect("/wittyoutfit/account_activation/index.html");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
