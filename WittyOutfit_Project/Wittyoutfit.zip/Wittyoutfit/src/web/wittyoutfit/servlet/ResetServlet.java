package web.wittyoutfit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import web.wittyoutfit.util.AuthUtil;
import web.wittyoutfit.util.HBUtil;
import web.wittyoutfit.model.Alive;
import web.wittyoutfit.model.UserCredential;
import web.wittyoutfit.service.resetPassword;
import web.wittyoutfit.service.mailservice;



@WebServlet("/ResetServlet")
public class ResetServlet extends HttpServlet {
	String authKey = null;
	private static final long serialVersionUID = 1L;
       
    
    public ResetServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
			String mail = request.getParameter("email");
			Session session = HBUtil.get().openSession();
			Criteria criteria = session.createCriteria(UserCredential.class);
			criteria.add(Restrictions.eq("emailId", mail));
			UserCredential user= (UserCredential) criteria.uniqueResult();
			if(user.getAlive()==Alive.ACTIVATED) {
			 System.out.println(mail);
			 authKey = AuthUtil.generateKey(7);
			 String froma="internshipwittyoutfit@gmail.com";
			 String email=mail;
			 String password="test@success007";
			 String subject = "Password Reset";
			 String body="Hi"+" "+ email + ",you have password reset link. Now reactivate your account with link +"+ " " + "<a href='http://localhost:8080/wittyoutfit/Reset?mail="+ ""+email+ "&key="+""+authKey+"'>CLICK HERE</a>" ;
			 mailservice.psend(email, froma, password, subject, body);
			 resetPassword.change(email,authKey);
			 response.sendRedirect("/wittyoutfit/success.html");
			}else {
		       	response.sendRedirect("/wittyoutfit/account_activation/index.html");	
			}
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
