package web.wittyoutfit.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import web.wittyoutfit.util.HBUtil;
import web.wittyoutfit.model.UserCredential;
import web.wittyoutfit.service.UserService;;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		try (PrintWriter out = response.getWriter()) {
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			if (username == null || username.isEmpty() || password == null || password.isEmpty() ) {
				out.println("Fill the required fields!");
			} else {
				String value = null;;
				boolean res=UserService.check(username,password);
				value = username;
				Session sess = HBUtil.get().openSession();
				Criteria criteria = sess.createCriteria(UserCredential.class);
				criteria.add(Restrictions.eq("emailId", value));
				UserCredential user= (UserCredential) criteria.uniqueResult();
				System.out.println(user.getAlive());
				if(res==false){
					out.println("LOGIN ERROR");
					request.getRequestDispatcher("error.html").forward(request, response);
				}
				else{
					if(String.valueOf(user.getAlive()).equals("ACTIVATED")) {
					 out.println("LOGIN success");
					 Cookie cookie = new Cookie("usr_alive", username);
					 cookie.setMaxAge(24*60*60);
					 response.addCookie(cookie);
					 String redirect = "/wittyoutfit/pages/examples/profile.jsp?mail="+username;
					 System.out.print(redirect);
					 response.sendRedirect(redirect);
					}else {
						out.println("NOT_ACTIVATED");
						response.sendRedirect("account_activation/index.html");
					}
				}
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
