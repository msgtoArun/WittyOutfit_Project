package web.wittyoutfit.util;

import java.security.SecureRandom;

public class AuthUtil {
	static final String taskString = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	static SecureRandom rnd = new SecureRandom();
	public static String generateKey(int length) {
		StringBuilder sb = new StringBuilder(length);
		for(int j = 0;j < length;j++) {
			sb.append(taskString.charAt(rnd.nextInt(taskString.length())));
		}
		return sb.toString();
	}

}
