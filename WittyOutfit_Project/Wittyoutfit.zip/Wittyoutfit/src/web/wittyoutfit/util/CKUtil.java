package web.wittyoutfit.util;


import javax.servlet.http.Cookie;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CKUtil {

	public static String get(HttpServletRequest request, String name) {
		
		String value = null;
		Cookie cookies[] = request.getCookies();
		System.out.println(cookies);
		if (cookies != null) {
			System.out.println("value"+name);
			for (int i = 0; i < cookies.length; i++) {
				System.out.println(cookies[i].getName());
				if(cookies[i].getName().equals(name)) {
					value = cookies[i].getValue();
					break;
				}
			}
		}
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if(cookies[i].getValue().equals(name)) {
					value = cookies[i].getValue();
					break;
				}
			}
		}
		System.out.println("value"+value);
		return value;
	}

	
	public static void remove(HttpServletResponse response, String name) {
		Cookie cookie = new Cookie(name,"");
		cookie.setMaxAge(0);
		response.addCookie(cookie);
		return;
	}
}
