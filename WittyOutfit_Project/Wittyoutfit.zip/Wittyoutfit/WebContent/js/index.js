function mailsent(){
	alert("Sending Message");
	var ajx;
	var data;
	var name = document.getElementById('name').value;
	var email = document.getElementById('email').value;
	var subject = document.getElementById('subject').value;
	var body = document.getElementById('message').value;
	//alert(body);
	if (XMLHttpRequest) {
		ajx = new XMLHttpRequest();
	} else {
		ajx = new ActiveXobject("Microsoft.XMLHttp");
	}
	
	ajx.open("POST", "/wittyoutfit/mailservlet",true);
	ajx.onreadystatechange = function() {
		if ((this.readyState === 4) && (this.status === 200)) {
			data = JSON.parse(this.responseText);
			alert("going")
		}
	}
	alert("Message Sent");
	var stp = null;
	ajx.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	stp = "name="+name+"&email="+email+"&subject="+subject+"&body="+body;
	ajx.send(stp);
}